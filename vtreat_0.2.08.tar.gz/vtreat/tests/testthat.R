library(testthat)
library(vtreat)

test_check("vtreat")
